package com.example.rehlahapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

public class LogIn extends AppCompatActivity {
    EditText email;
    EditText password;
    ImageButton signIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        email = (EditText) findViewById(R.id.editTextTextTitle);
        password = (EditText) findViewById(R.id.editTextTextPassword);
        signIn = (ImageButton) findViewById(R.id.imageButton11);

    }
    public void onClickBack (View v){
        onBackPressed();
    }
    public void onClickDont(View v) {
        Intent intent = new Intent(LogIn.this,Register.class);
        startActivity(intent);
    }
    public void onClickLog(View v) {
        Intent intent = new Intent(LogIn.this,ListOfServiceProviders.class);
        startActivity(intent);
    }

}