package com.example.rehlahapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ListOfServiceProviders extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_service_providers);
    }
    public void onClickBack (View v){
        onBackPressed();
    }
    public void onClickLogout(View v) {
        Intent intent = new Intent(ListOfServiceProviders.this,LogIn.class);
        startActivity(intent);
    }
    public void onClickTrips(View v) {
        Intent intent = new Intent(ListOfServiceProviders.this,MyTrips.class);
        startActivity(intent);
    }
    public void onClickgoTrip(View v) {
        Intent intent = new Intent(ListOfServiceProviders.this,CarDetails.class);
        startActivity(intent);
    }
}