package com.example.rehlahapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ReservationINFo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation_i_n_fo);
    }
    public void onClickBack (View v){
        onBackPressed();
    }
    public void onClickToPay(View v) {
        Intent intent = new Intent(ReservationINFo.this,PaymentPage.class);
        startActivity(intent);
    }
}