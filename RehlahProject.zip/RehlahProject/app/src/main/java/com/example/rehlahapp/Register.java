package com.example.rehlahapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.vishnusivadas.advanced_httpurlconnection.PutData;

public class Register extends AppCompatActivity {
    EditText email;
    EditText password;
    EditText confirmPassword;
    ImageButton signUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        email = (EditText) findViewById(R.id.editEmail);
        password = (EditText) findViewById(R.id.editPassword);
        confirmPassword = (EditText) findViewById(R.id.vertifyPass);
        signUp = (ImageButton) findViewById(R.id.register);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emailText, passwordText, confirmPasswordText;
                emailText = String.valueOf(email.getText());
                passwordText = String.valueOf(password.getText());
                confirmPasswordText = String.valueOf(confirmPassword.getText());

                if(!emailText.equals("") && !passwordText.equals("") && !confirmPasswordText.equals("")) {

                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //Starting Write and Read data with URL
                            //Creating array for parameters
                            String[] field = new String[3];
                            field[0] = "emailText";
                            field[1] = "passwordText";
                            field[2] = "confirmPasswordText";
                            //Creating array for data
                            String[] data = new String[3];
                            data[0] = emailText;
                            data[1] = passwordText;
                            data[2] = confirmPasswordText;
                            PutData putData = new PutData("http://192.168.8.101/LoginRegister/signup.php", "POST", field, data);
                            if (putData.startPut()) {
                                if (putData.onComplete()) {
                                    String result = putData.getResult();
                                    if(result.equals("Sign Up Success")){
                                        Intent intent = new Intent(getApplicationContext(),LogIn.class);
                                        startActivity(intent);
                                        finish();

                                    }
                                    else {
                                        Toast.makeText(getApplicationContext(),"تم التسجيل" ,Toast.LENGTH_SHORT).show();
                                    }

                                }
                            }

                        }
                    });
                }
                else {
                    Toast.makeText(getApplicationContext(),"جميع الحقول مطلوبة!" ,Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
    public void onClickBack (View v){
        onBackPressed();
    }
}