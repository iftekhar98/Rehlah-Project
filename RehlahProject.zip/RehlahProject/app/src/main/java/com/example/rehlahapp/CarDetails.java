package com.example.rehlahapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CarDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_details);
    }
    public void onClickBack (View v){
        onBackPressed();
    }
    public void onClickBook(View v) {
        Intent intent = new Intent(CarDetails.this,ReservationINFo.class);
        startActivity(intent);
    }
    public void onClickchat(View v) {
        Intent intent = new Intent(CarDetails.this,Chat.class);
        startActivity(intent);
    }
    public void onClickRanking(View v) {
        Intent intent = new Intent(CarDetails.this,RatingPage.class);
        startActivity(intent);
    }
}