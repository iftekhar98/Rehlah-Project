package com.example.rehlahapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class SelectType extends AppCompatActivity {
    ImageButton back;
    ImageButton add;
    ImageButton reserve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_type);
        back = (ImageButton) findViewById(R.id.back);
        add = (ImageButton) findViewById(R.id.add);
        reserve = (ImageButton) findViewById(R.id.reserve);
    }
    public void onClickAdd(View v) {
        Intent intent = new Intent(SelectType.this,LogIn.class);
        startActivity(intent);
    }
    public void onClickRes(View v) {
        Intent intent = new Intent(SelectType.this,LogIn.class);
        startActivity(intent);
    }
    public void onClickBack (View v){
        onBackPressed();
    }
}